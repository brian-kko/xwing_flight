import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.awt.event.*;

public class Panel extends JPanel implements KeyListener
{
    private Frame parentFrame;
    public final int WIDTH = 1280;
    public final int HEIGHT = 720;
    public boolean on = true;
    private double x = 300;
    private double y = 300;
    private int firePos = 0;
    private boolean w, a, s, d;
    private int minute, second, runningTime;
    private ArrayList<Sprite> playerProjectiles = new ArrayList<Sprite>();
    private ArrayList<Enemy> enemies = new ArrayList<Enemy>();
    private ArrayList<EnemyBoss> bosses = new ArrayList<EnemyBoss>();
    private ArrayList<EnemyProjectile> enemyProjectiles = new ArrayList<EnemyProjectile>();
    private ArrayList<Background> backgrounds = new ArrayList<Background>();
    private ArrayList<Background> foregrounds = new ArrayList<Background>();
    private ArrayList<Sprite> explosions = new ArrayList<Sprite>();
    public Player player;
    private Background background;
    private Background background2;
    private Background foreground;
    private Background foreground2;
    private int shieldCD = 5;
    private int currentHealth = 7;
    private int currentShield = 5;
    private boolean movingUp = false;
    private boolean movingDown = false;
    private int randInt=0;
    
    private int score = 0;
    private JLabel winMessage;
    private JLabel scoreLabel;
    private int winTime=-1;
    private boolean won=false;

    private int bossPhase = 0;
    
    private boolean paused = true;
    private int torpedo=1;

    private final int BOMBERMAXHP = 10;
    private final int FIGHTERMAXHP = 5;


    private JLabel timerLabel;
    private Image playerSprite;
    private Image spaceBG;
    private Image spaceFG;
    private Image tieFighter;
    private Image laserRed;
    private Image laserGreen;
    private Image tieBomber;
    private Image energyBall;
    private Image tieAdvanced;
    private Image starDestroyer;
    private Image deathStar;
    private Image boom;
    private Image blast;

    private Thread game;
    private Thread timer;
    private Thread bg;
    private Thread fg;

    public Panel(Frame parentFrame)
    {
        this.parentFrame = parentFrame;
        this.setLayout(null);
        this.setBounds(0, 0, WIDTH, HEIGHT);
        this.setPreferredSize(new Dimension(WIDTH, HEIGHT));
        this.addKeyListener(this);
        this.setFocusable(true);

        timerLabel = new JLabel();
        timerLabel.setBounds(WIDTH/2, 40, 200, 10);
        this.add(timerLabel);

        winMessage = new JLabel();
        winMessage.setBounds(WIDTH/2, HEIGHT/2, 200, 100 ); 
        this.add(winMessage);

        scoreLabel = new JLabel();
        scoreLabel.setBounds(20,20,300, 10);
        this.add(scoreLabel);

        start();
    }

    public void start()
    {
        playerSprite = Sprite.resizeImg("MP4/assets/temp/x_wing.png", 100, 45);//https://www.pinterest.co.uk/pin/539095017879561103/
        spaceBG = Sprite.resizeImg("MP4/assets/temp/space.jpg", WIDTH, HEIGHT);//https://wallpapersafari.com/star-wars-space-backgrounds-hq/
        spaceFG = Sprite.resizeImg("MP4/assets/temp/space2.png", WIDTH, HEIGHT);
        tieFighter = Sprite.resizeImg("MP4/assets/temp/tie_fighter.png", 100, 85); //http://www.galacticempiredatabank.com/TIEFighter.html
        laserRed = Sprite.resizeImg("MP4/assets/temp/laser_red.png", 35, 10); //https://www.moddb.com/mods/empire-at-war-re/images/new-turbolaser-textures
        tieBomber = Sprite.resizeImg("MP4/assets/temp/tie_bomber.png", 80, 60); //https://www.deviantart.com/adit1001/art/Tie-Bomber-15152926
        laserGreen = Sprite.resizeImg("MP4/assets/temp/laser_green.png", 35, 10);
        energyBall = Sprite.resizeImg("MP4/assets/temp/energy_ball.png", 30, 30);
        tieAdvanced = Sprite.resizeImg("MP4/assets/temp/tie_advanced.png", 100, 60); //https://static.wikia.nocookie.net/starwarsrebels/images/9/9b/Rebels_TIE_Advance_X1.png/revision/latest?cb=20170628065226
        starDestroyer = Sprite.resizeImg("MP4/assets/temp/star_destroyer.png", 1050, 600); //https://www.reddit.com/r/StarWars/comments/hv3dfx/rogue_one_imperial_iclass_star_destroyer_4k/
        deathStar = Sprite.resizeImg("MP4/assets/temp/death_star.png", 1200, 1200); //https://starwars.fandom.com/wiki/DS-1_Orbital_Battle_Station/Legends
        blast = Sprite.resizeImg("MP4/assets/temp/blast.png", 50, 30);
        boom = Sprite.resizeImg("MP4/assets/temp/boom.png", 50, 50);

        player = new Player(x, y, 100, 45, 3, 3, 7, 5, playerSprite);
        background = new Background(spaceBG, 0, 0);
        background2 = new Background(spaceBG, WIDTH, 0);
        foreground = new Background(spaceFG, 0, 0);
        foreground2 = new Background(spaceFG, WIDTH, 0);
        backgrounds.add(background);
        backgrounds.add(background2);
        foregrounds.add(foreground);
        foregrounds.add(foreground2);

        game = new Thread(new Runnable() {

            @Override
            public void run() {
                // TODO Auto-generated method stub
                while(on)
                {
                    if(!paused)
                    {
                        scoreLabel.setForeground(Color.WHITE);
                        scoreLabel.setText("" + score);

                        if(player.health()==0)
                        {
                            player.setXVelocity(0);
                            player.setYVelocity(0);
                            player.setImage(null);
                            explosions.add(new Sprite(player.x(), player.y(), player.width(), player.height(), boom, 1));
                        }
                        if(bosses.size()==0)
                        {
                            if(w && player.y()>0) player.setY(player.y()-4);
                            if(a && player.x()>0) player.setX(player.x()-4);
                            if(s && player.y()<HEIGHT-50) player.setY(player.y()+4);
                            if(d && player.x()<WIDTH-50) player.setX(player.x()+4);
                        }
                        else
                        {
                            if(bossPhase==4)
                            {
                                player.setXVelocity(0);
                                player.setYVelocity(0);
                                if(player.x()!=350 && player.x()>350) player.setX(player.x()-1);
                                if(player.x()!=350 && player.x()<350) player.setX(player.x()+1);
                                if(player.y()!=350 && player.x()>350) player.setY(player.y()-1);
                                if(player.y()!=350 && player.x()<350) player.setY(player.y()+1);
                            }
                            else
                            {
                                if(player.x()>WIDTH-500) player.setX(player.x()-1);
                                if(w && player.y()>0) player.setY(player.y()-4);
                                if(a && player.x()>0) player.setX(player.x()-4);
                                if(s && player.y()<HEIGHT-50) player.setY(player.y()+4);
                                if(d && player.x()<WIDTH-500) player.setX(player.x()+4);
                            }
                        }

                        for(int i=0; i<playerProjectiles.size(); i++)
                        {
                            Sprite s = playerProjectiles.get(i);
                            s.setX(s.x() + s.xVelocity);
                            s.setY(s.y() + s.yVelocity);

                            if(s.x() > WIDTH || s.x() < 0 || s.y() > HEIGHT || s.y() < 0) playerProjectiles.remove(i);

                            for(int j = 0; j < enemies.size(); j++)
                            {
                                if(s.collidesWith(enemies.get(j)))
                                {
                                    if(enemies.get(j).health() > 0) enemies.get(j).setHealth(enemies.get(j).health() - 1);
                                    if(enemies.get(j).health() == 0) 
                                    {
                                        explosions.add(new Sprite(enemies.get(j).x(), enemies.get(j).y(), enemies.get(j).width(), enemies.get(j).height(), boom, 1));
                                        enemies.remove(j);
                                        score+=10;
                                    }
                                    playerProjectiles.remove(s);
                                }
                            }

                            for(int k = 0; k < bosses.size(); k++)
                            {
                                if(s.collidesWith(bosses.get(k)))
                                {
                                    if(s.image()==blast)
                                    {
                                        bosses.get(k).setHealth(0);
                                        playerProjectiles.remove(s);
                                        winTime=runningTime;
                                    }
                                    
                                    
                                    if(bosses.get(k).shield() > 0) bosses.get(k).setShield(bosses.get(k).shield()-1);
                                    else if(bosses.get(k).health() > 0) bosses.get(k).setHealth(bosses.get(k).health() - 1);
                                    if(bosses.get(k).health() == 0)
                                    {
                                        if(bosses.get(k).name.equals("tie")) 
                                        {
                                            explosions.add(new Sprite(bosses.get(k).x(), bosses.get(k).y(), bosses.get(k).width(), bosses.get(k).height(), Sprite.resizeImg("MP4/assets/temp/boom.png", 100, 100), 1));
                                            bosses.remove(k);
                                            score+=400;
                                            // winMessage.setForeground(Color.WHITE);
                                            // winMessage.setText("You win!");
                                            winTime = 3;
                                        }
                                        else if(bosses.get(k).name.equals("death"))
                                        {
                                            explosions.add(new Sprite(bosses.get(k).x(), bosses.get(k).y(), bosses.get(k).width(), bosses.get(k).height(), Sprite.resizeImg("MP4/assets/temp/boom.png", 1200, 1200), 1));
                                            bosses.remove(k);
                                            score+=500;
                                            won=true;
                                        }
                                    }
                                    playerProjectiles.remove(s);
                                    
                                }
                            }
                        }

                        for(int i=0; i<bosses.size(); i++)
                        {
                            EnemyBoss b = bosses.get(i);
                            if(b.image()==tieAdvanced)
                            {
                                b.setX(b.x() + b.xVelocity());
                                b.setY(b.y() + b.yVelocity());

                                if(b.passedX(WIDTH - 200))
                                {
                                    b.setXVelocity(0);
                                    b.setX(WIDTH -199);
                                }

                                if(b.x()==WIDTH-199)
                                {
                                    if(b.cooldown()==0) b.setCooldown(9000);
                                    if(b.cooldown()%500==0) {attack1((int)b.x(),(int) b.y()); System.out.println(b.cooldown());}
                                    if((b.cooldown()<8800 && b.cooldown()>8000) || (b.cooldown()<7000 && b.cooldown()>6200) || (b.cooldown()<5200 && b.cooldown()>4400) || (b.cooldown()<3400 && b.cooldown()>2600) || (b.cooldown()<1600 && b.cooldown()> 800))
                                    {
                                        if(b.y()>player.y() && b.y()>0) b.setY(b.y()-2); 
                                        if(b.y()<player.y() && b.y()<HEIGHT-50) b.setY(b.y()+2); 
                                        if(b.cooldown()%20==0 && b.cooldown()%30!=0) enemyProjectiles.add(new EnemyProjectile(b.x(), b.y()+40, 30, 10, -4,  + i, laserGreen, "laser"));
                                    }
                                    else
                                    {
                                        if(b.y()>HEIGHT/2) b.setY(b.y()-1);
                                        if(b.y()<HEIGHT/2) b.setY(b.y()+1);
                                        
                                        if(b.cooldown()%550==0) spawnWave(2);
                                    }
                                    b.setCooldown(b.cooldown()-1);
                                }
                            }

                            if(b.image()==starDestroyer)
                            {
                                b.setX(b.x() + b.xVelocity());
                                b.setY(b.y() + b.yVelocity());

                                if(b.health()<=0) {b.setYVelocity(1);}
                                if(b.y()> .5*WIDTH) {bosses.remove(b); score+=300;}

                                if(b.passedX(WIDTH - 200))
                                {
                                    b.setXVelocity(0);
                                    b.setX(WIDTH -199);
                                    b.setYDir(1);
                                }

                                if(b.x() == WIDTH-199)
                                {
                                    if(b.cooldown==0) b.setCooldown(2000);
                                    if((b.cooldown()==2000)||(b.cooldown()==1500)||(b.cooldown()==1000)||(b.cooldown()==500)) randInt = (int)(Math.random()*5);
                                    if(b.cooldown()%400==0 && enemies.size() <= 3) enemies.add(new Enemy(WIDTH, randY(), 60, 100, -1, posNeg1(), BOMBERMAXHP, tieBomber, "tieBomber", 3000));
                                    if(((b.cooldown() < 2000 && b.cooldown() > 1700) || (b.cooldown()<1500 && b.cooldown()>1200) || (b.cooldown()<1000 && b.cooldown()>700) || (b.cooldown()<500) && b.cooldown()>200) && b.yVelocity()==0)
                                    {
                                        if(randInt==0)
                                        {
                                            if(b.cooldown()%20==0) 
                                            {
                                                enemyProjectiles.add(new EnemyProjectile(870, 580, 30, 10, -2, -4, Sprite.rotate(laserGreen, 1.1), "laser"));
                                                enemyProjectiles.add(new EnemyProjectile(910, 555, 30, 10, -2,  -4, Sprite.rotate(laserGreen, 1.1), "laser"));
                                                enemyProjectiles.add(new EnemyProjectile(950, 520, 30, 10, -2,  -4, Sprite.rotate(laserGreen, 1.1), "laser"));
                                            }
                                        }
                                        else if(randInt==1)
                                        {
                                            if(b.cooldown()%20==0) 
                                            {
                                                enemyProjectiles.add(new EnemyProjectile(870, 580, 30, 10, -3, -3, Sprite.rotate(laserGreen, .8), "laser"));
                                                enemyProjectiles.add(new EnemyProjectile(910, 555, 30, 10, -3,  -3, Sprite.rotate(laserGreen, .8), "laser"));
                                                enemyProjectiles.add(new EnemyProjectile(950, 520, 30, 10, -3,  -3, Sprite.rotate(laserGreen, .8), "laser"));
                                            }
                                        }
                                        
                                        else if(randInt==2)
                                        {
                                            if(b.cooldown()%20==0) 
                                            {
                                                enemyProjectiles.add(new EnemyProjectile(870, 580, 30, 10, -4, -2, Sprite.rotate(laserGreen, .46), "laser"));
                                                enemyProjectiles.add(new EnemyProjectile(910, 555, 30, 10, -4,  -2, Sprite.rotate(laserGreen, .46), "laser"));
                                                enemyProjectiles.add(new EnemyProjectile(950, 520, 30, 10, -4,  -2, Sprite.rotate(laserGreen, .46), "laser"));
                                            }
                                        }

                                        else if(randInt==3)
                                        {
                                            if(b.cooldown()%20==0) 
                                            {
                                                enemyProjectiles.add(new EnemyProjectile(870, 580, 30, 10, -5, -1, Sprite.rotate(laserGreen, .2), "laser"));
                                                enemyProjectiles.add(new EnemyProjectile(910, 555, 30, 10, -5,  -1, Sprite.rotate(laserGreen, .2), "laser"));
                                                enemyProjectiles.add(new EnemyProjectile(950, 520, 30, 10, -5,  -1, Sprite.rotate(laserGreen, .2), "laser"));
                                            }
                                        }
                                        else
                                        {
                                            if(b.cooldown()%20==0) 
                                            {
                                                enemyProjectiles.add(new EnemyProjectile(870, 580, 30, 10, -6, 0, Sprite.rotate(laserGreen, 0), "laser"));
                                                enemyProjectiles.add(new EnemyProjectile(910, 555, 30, 10, -6,  0, Sprite.rotate(laserGreen, 0), "laser"));
                                                enemyProjectiles.add(new EnemyProjectile(950, 520, 30, 10, -6,  0, Sprite.rotate(laserGreen, 0), "laser"));
                                            }
                                        }
                                    }

                                    b.setCooldown(b.cooldown()-1);
                                }

                            }
                        
                            if(b.image()==deathStar)
                            {
                                b.setX(b.x() + b.xVelocity());
                                b.setY(b.y() + b.yVelocity());
                                if(b.passedX(WIDTH - 500)&&bossPhase!=4)
                                {
                                    b.setCooldown(300);
                                    b.setXVelocity(0);
                                    b.setX(WIDTH -499);
                                }
                            
                                if(b.x()==WIDTH-499)
                                {
                                    b.setCooldown(b.cooldown()-1);
                                    if(b.cooldown()==0) b.setXVelocity(1);
                                    
                                }

                                if(b.xVelocity()==1 && b.x()==WIDTH) 
                                {
                                    b.setXVelocity(0);
                                    b.setCooldown(1200);
                                }

                                if(b.x()==WIDTH)
                                {
                                    if(bossPhase==0)
                                    {
                                        if(b.cooldown()<= 1000 && b.cooldown() >0 && b.cooldown() % 200==0) laserAttack(true);
                                        if(b.cooldown()==0) {b.setCooldown(1000); bossPhase++;}
                                    }

                                    if(bossPhase==1)
                                    {
                                        if(b.cooldown()<= 1000 && b.cooldown() >0 && b.cooldown() % 150==0) {laserAttack();}
                                        if(b.cooldown()==0) {b.setCooldown(1000); bossPhase++;}
                                    }

                                    if(bossPhase==2)
                                    {
                                        if(b.cooldown()<= 1000 && b.cooldown() >0 && b.cooldown() % 150==0) {laserAttack(); laserAttack();}
                                        if(b.cooldown()==0) {b.setCooldown(1000); bossPhase++;}
                                    }

                                    if(bossPhase==3)
                                    {
                                        if(b.cooldown()<= 1000 && b.cooldown() >0) 
                                        {
                                            if(b.cooldown() % 200==0)laserAttack((int)player.x());
                                            if(b.cooldown() % 150==0) laserAttack();
                                        }
                                        if(b.cooldown()==0) b.setCooldown(1300);
                                        if(b.cooldown()==1100) {b.setXVelocity(-1); bossPhase++;}
                                    }
                                    b.setCooldown(b.cooldown()-1);
                                }

                                if(bossPhase == 4 && b.xVelocity()==-1 && b.x()==550)
                                {
                                    b.setXVelocity(0);
                                }

                                // if(bossPhase==4 && b.x() == 550 && b.xVelocity()==0)
                                // {
                                //     // explosions.add(new Sprite(b.x(), b.y(), b.width(), b.height(), Sprite.resizeImg("MP4/assets/temp/boom.png", 1000, 1000) , 2));
                                //     if(b.health()==0) bosses.remove(b);
                                // }
                            }
                        }

                        for(int i=0; i<enemies.size(); i++)
                        {
                            Enemy e = enemies.get(i);
                            if(e.image()==tieFighter)
                            {
                                e.setX(e.x() + e.xVelocity());
                                e.setY(e.y() + e.yVelocity());

                                if(e.cooldown() == 0 || e.cooldown() == 2000 || e.cooldown() == 4000)
                                {
                                    enemyProjectiles.add(new EnemyProjectile(e.x(), e.y()+45, 30, 10, -3, 0, laserGreen, "laser"));
                                    if(e.cooldown()==0) e.setCooldown(30000);
                                }

                                e.setCooldown(e.cooldown() - 100);
                            }
                            if(e.image()==tieBomber)
                            {
                                if(e.passedX(WIDTH - 300))
                                {
                                    e.setXVelocity(0);
                                    e.setX(WIDTH -299);
                                }
                                else if(e.x() == WIDTH - 299)
                                {
                                    e.setY(e.y() + e.yVelocity());
                                    if(e.y() > HEIGHT-200) e.setYVelocity(-1);
                                    if(e.y() < 150) e.setYVelocity(1);

                                    if(e.cooldown() == 0)
                                    {
                                        enemyProjectiles.add(new EnemyProjectile(e.x(), e.y(), 30, 30, -2, 0, energyBall, "ball"));
                                        if(e.cooldown()==0) e.setCooldown(50000);
                                    }
                                    e.setCooldown(e.cooldown()-100);
                                }
                                
                                else
                                {
                                    e.setX(e.x() + e.xVelocity());
                                }
                            }
                            if(e.x() < -50 || e.y() > HEIGHT || e.y() < -50) enemies.remove(i);
                            
                            else if(player.collidesWith(enemies.get(i)))
                            {
                                enemies.remove(i);
                                System.out.println("Collided");
                                
                                if(player.shield() > 0) player.setShield(0);
                                else if(player.health() > 2) player.decreaseHealth(3);
                                else player.setHealth(0);
                            }
                        }

                        for(int i=0; i<enemyProjectiles.size(); i++)
                        {
                            EnemyProjectile  e = enemyProjectiles.get(i);
                            if(e.name().equals("laser"))
                            {
                                e.setX(e.x() + e.xVelocity());
                                e.setY(e.y() + e.yVelocity());
                            }

                            if(e.name().equals("ball"))
                            {
                                double slope = (e.y()-player.y()-25)/(e.x() - player.x()+25);
                                e.setX(e.x() + e.xVelocity());
                                if(!e.passedX(player.x()+10)) 
                                {
                                    e.setY(e.y() - (slope));
                                    e.setYVelocity(slope);
                                }
                                else
                                {
                                    e.setY(e.y()-e.yVelocity());
                                }
                            }

                            if(e.x() > WIDTH || e.x() < 0 || e.y() > HEIGHT || e.y() < 0) enemyProjectiles.remove(i);

                            if(e.name().equals("start"))
                            {
                                if(runningTime >= e.endTime())
                                {
                                    if(e.width()==WIDTH)
                                    {
                                        int currentTime = runningTime;
                                        enemyProjectiles.add(new EnemyProjectile(e.x(), e.y()-30, WIDTH, 80, 0, 0, null, "end", currentTime + 1,false));
                                        enemyProjectiles.remove(i);
                                    }
                                    else 
                                    {
                                        int currentTime = runningTime;
                                        enemyProjectiles.add(new EnemyProjectile(e.x()-30, e.y(), 80, HEIGHT, 0, 0, null, "end", currentTime + 1,false));
                                        enemyProjectiles.remove(i);
                                    }
                                }
                            }

                            if(e.name().equals("end"))
                            {
                                if(runningTime >e.endTime()) enemyProjectiles.remove(i);
                            }

                            if(e.collidesWith(player))
                            {
                                if(e.name().equals("laser"))
                                {
                                    if(player.shield() > 0) player.setShield(player.shield()-1);
                                    else if(player.health() > 0) player.setHealth(player.health() - 1);
                                    if(player.health() == 0) System.out.println("You died");
                                    enemyProjectiles.remove(e);
                                }
                                if(e.name().equals("ball"))
                                {
                                    if(player.shield() > 0) player.setShield(player.shield()-1);
                                    else if(player.health() > 0) player.setHealth(player.health() - 1);
                                    if(player.health() == 0) System.out.println("You died");
                                    enemyProjectiles.remove(e);
                                }
                                if(e.name().equals("end"))
                                {
                                    if(player.shield()>0 && !e.hit()) {player.setShield(0); e.setHit(true);}
                                    if(player.health()>0 && !e.hit()) {player.setHealth(0); e.setHit(true);}
                                }
                            }
                        }
                    }
                    
                    repaint();
                    try {
                        Thread.sleep(10);
                    } catch (InterruptedException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            }
            
        });
        game.start();

        timer = new Thread(new Runnable() {

            @Override
            public void run() {
                timerLabel.setForeground(Color.WHITE);
                // TODO Auto-generated method stub
                while(on) 
                {
                    if(!paused)
                    {
                        second++;
                        runningTime++;

                        if(winTime!=-1) winTime--;

                        //Spawning times
                        if(runningTime==30 && bosses.size()==0)  bosses.add(new EnemyBoss((WIDTH +500), HEIGHT/2 -150, 350, 150, -.5, 0, 30, 40, starDestroyer, "destroyer", 0, -1));

                        if(runningTime==90 && bosses.size()==0) bosses.add(new EnemyBoss(WIDTH, HEIGHT/2, 80, 60, -.5, 0, 40, 20, tieAdvanced, "tie", 0, posNeg1()));

                        if(runningTime==180 && bosses.size()==0) {bosses.add(new EnemyBoss((WIDTH + 600), 0, 1100, 1100, -1, 0, 999, 0, deathStar, "death", 0, -1)); laserAttack((int)player.x());}

                        if(runningTime<120 && bosses.size()==0 && !won) 
                        {
                            if(runningTime%3==0) spawnWaveRand(1);
                            if(runningTime%7==0) spawnWave(2);
                            if(runningTime%10==0) enemies.add(new Enemy(WIDTH, randY(), 60, 100, -1, posNeg1(), BOMBERMAXHP, tieBomber, "tieBomber", 3000));
                        }

                        if(runningTime>120 && runningTime <155 && bosses.size()==0 && !won) 
                        {
                            if(runningTime%2==0) spawnWaveRand(1);
                            if(runningTime%8==0) spawnWave(3);
                            if(runningTime%7==0) enemies.add(new Enemy(WIDTH, randY(), 60, 100, -1, posNeg1(), BOMBERMAXHP, tieBomber, "tieBomber", 3000));

                        }


                        if(player.health()>0)
                        {
                            if(currentHealth!=player.health() || currentShield!=player.shield())
                            {
                                shieldCD = 5;
                                currentHealth = player.health();
                                currentShield = player.shield();
                            }

                            if(player.shield() < 5)
                            {
                                shieldCD--;
                            }

                            if(shieldCD <= 0 && player.shield()<5)
                            {
                                player.setShield(player.shield()+1);
                                currentShield = player.shield();
                            }
                        }

                        // System.out.println(second);
                        if(second == 60)
                        {
                            second=0;
                            minute++;
                        //     System.out.println(minute +" minute(s)");
                        }
                        if(second < 10)
                        {
                            timerLabel.setText(minute + ":0" + second);
                        }
                        else
                        {
                            timerLabel.setText(minute + ":" + second);
                        }

                        if(second%5==0)
                        {
                            // spawnWave(5);
                            // enemies.add(new Enemy(WIDTH, randY(), 50, 70, -1, 0, 3, tieFighter));
                        }

                        for(int i=0; i<explosions.size();i++)
                        {
                            if(explosions.get(i).duration()<=0) explosions.remove(i);
                        }

                        for(Sprite s: explosions)
                        {
                            s.setDuration();
                        }
                        
                    }

                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            }
            
        });

        timer.start();

        bg = new Thread(new Runnable() {

            @Override
            public void run() {
                // TODO Auto-generated method stub
                while(on)
                {
                    if(!paused)
                    {
                        for(Background b: backgrounds)
                        {
                            if(b.x() < -WIDTH)
                            {
                                b.setX(WIDTH);
                            }
                            b.setX(b.x()-1);
                        }
                    }

                    int i=50;
                    if(won) i=2;

                    try {
                        Thread.sleep(i);
                    } catch (InterruptedException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            }
        });

        bg.start();

        fg = new Thread(new Runnable() {

            @Override
            public void run() {
                // TODO Auto-generated method stub
                while(on)
                {
                    if(!paused)
                    {
                        for(Background f: foregrounds)
                        {
                            if(f.x() < -WIDTH)
                            {
                                f.setX(WIDTH);
                            }
                            f.setX(f.x()-1);
                        }
                    }

                    int i=35;
                    if(won) i=1;

                    try {
                        Thread.sleep(i);
                    } catch (InterruptedException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            }
        });

        fg.start();
    }

    public void restart()
    {
        on=false;
        while(game.isAlive() || timer.isAlive() || bg.isAlive() || fg.isAlive()) {}
        start();
    }

    public void paint(Graphics g)
    {
        super.setBackground(Color.black);
        super.paint(g);
        Graphics2D g2d = (Graphics2D) g;
        
        for(Background b: backgrounds) b.draw(g2d);
        for(Background f: foregrounds) f.draw(g2d);
       

        for(EnemyBoss b: bosses)
        {
            b.draw(g2d);
        }

        if(movingUp || movingDown)
        {
            if(movingUp) player.setImage(Sprite.rotate(playerSprite, -.4));
            else player.setImage(Sprite.rotate(playerSprite, .4));
        }
        else player.setImage(Sprite.rotate(playerSprite, 0));
        
        if(player.health()>0)player.draw(g2d);
        
        for(Sprite s: playerProjectiles) 
        {
            g2d.setColor(new Color(191, 19, 19, 200));
            s.draw(g2d);
        }

        for(Enemy e: enemies)
        {
            g2d.setColor(new Color(53, 61, 55));
            e.draw(g2d);
        }


        for(EnemyProjectile e: enemyProjectiles)
        {
            e.draw(g2d);
        }

        for(Sprite s: explosions)
        {
            s.draw(g2d);
        }


        super.paintComponents(g);
    }

    @Override
    public void keyTyped(KeyEvent e) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void keyPressed(KeyEvent e) {
        // TODO Auto-generated method stub
        if(e.getKeyCode()==87) 
        {
            w = true;
            if(s) movingUp = false;
            else movingUp = true;
            // if(s) player.setImage(Sprite.rotate(playerSprite, 0));
            // else player.setImage(Sprite.rotate(playerSprite, -.4));
        }
        else if(e.getKeyCode()==65) a = true;
        else if(e.getKeyCode()==83) 
        {
            s = true;
            if(w) movingDown = false;
            else movingDown = true;
            // if(w) player.setImage(Sprite.rotate(playerSprite, 0));
            // else player.setImage(Sprite.rotate(playerSprite, .4));
        }
        else if(e.getKeyCode()==68) d = true;
    }

    @Override
    public void keyReleased(KeyEvent e) {
        if(player.health>0)
        {
            System.out.println(e.getKeyCode()+ " " + e.getKeyChar());
            if(!paused)
            {
                if(e.getKeyCode()==87) 
                {
                    w = false;
                    movingUp = false;
                    if(s) movingDown = true;
                    else movingDown = false;
                    // if(s) player.setImage(Sprite.rotate(playerSprite, .4));
                    // else player.setImage(Sprite.rotate(playerSprite, 0));
                }
                else if(e.getKeyCode()==65) a = false;
                else if(e.getKeyCode()==83) 
                {
                    s = false;
                    movingDown = false;
                    if(w) movingUp = true;
                    else movingUp = false;
                    // if(w) player.setImage(Sprite.rotate(playerSprite, -.4));
                    // else player.setImage(Sprite.rotate(playerSprite, 0));
                }
                else if(e.getKeyCode()==68) d = false;
                else if(e.getKeyCode()==32)
                {
                    if(bossPhase!=4)
                    {
                        if(movingUp)
                        {
                            if(firePos==0) 
                            {
                                playerProjectiles.add(new Sprite(player.x() + 70, player.y() + 5, 10, 10, 4, -2, Sprite.rotate(laserRed,-.4))); //x and y for Player class
                                firePos++;
                            }
                            else 
                            {
                                playerProjectiles.add(new Sprite(player.x() + 70, player.y() + 32, 10, 10, 4, -2,Sprite.rotate(laserRed, -.4)));
                                firePos--;
                            }
                        }
                        else if(movingDown)
                        {
                            if(firePos==0) 
                            {
                                playerProjectiles.add(new Sprite(player.x() + 70, player.y() + 5, 10, 10, 4, 2, Sprite.rotate(laserRed,.4))); //x and y for Player class
                                firePos++;
                            }
                            else 
                            {
                                playerProjectiles.add(new Sprite(player.x() + 70, player.y() + 32, 10, 10, 4, 2,Sprite.rotate(laserRed, .4)));
                                firePos--;
                            }
                        }
                        else
                        {
                            if(firePos==0) 
                            {
                                playerProjectiles.add(new Sprite(player.x() + 70, player.y() + 5, 10, 10, 6, 0, laserRed)); //x and y for Player class
                                firePos++;
                            }
                            else 
                            {
                                playerProjectiles.add(new Sprite(player.x() + 70, player.y() + 32, 10, 10, 6, 0, laserRed));
                                firePos--;
                            }
                        }
                    }
                    else if(bosses.get(0).x()==550&&bossPhase==4 && torpedo==1)
                    {
                        playerProjectiles.add(new Sprite(player.x() + 70, player.y() + 32, 5, 10, 3, 0, blast));
                        torpedo--;
                    }
                }
                else if(e.getKeyCode()==80)
                {
                    enemies.add(new Enemy(WIDTH, randY(), 50, 70, -1, 0, FIGHTERMAXHP, tieFighter, "tieFighter", (int)(Math.random()+1 * 10)*1000));
                }
                else if(e.getKeyCode()==81) 
                {
                    spawnWave(5);
                }
                else if(e.getKeyCode()==79) enemies.add(new Enemy(WIDTH, randY(), 60, 100, -1, posNeg1(), BOMBERMAXHP, tieBomber, "tieBomber", 3000));
                
                else if(e.getKeyCode()==73) bosses.add(new EnemyBoss(WIDTH, HEIGHT/2, 80, 60, -.5, 0, 50, 40, tieAdvanced, "tie", 0, posNeg1()));
                
                else if(e.getKeyCode()==76) bosses.add(new EnemyBoss((WIDTH +500), HEIGHT/2 -150, 350, 150, -.5, 0, 50, 50, starDestroyer, "destroyer", 0, -1));

                else if(e.getKeyCode()==46) {bosses.add(new EnemyBoss((WIDTH + 600), 0, 1100, 1100, -1, 0, 999, 0, deathStar, "death", 0, -1)); laserAttack((int)player.x());}

                else if(e.getKeyCode()==44) laserAttack();

                // else if(e.getKeyCode()==46) restart();
            }

            if(e.getKeyCode()==10)
            {
                paused=false;
            } 
        }
    }

    public int randY()
    {
        int i = (int) (Math.random()*HEIGHT);
        if(i<60 || i>670)
        {
            return randY();
        }
        return i;
    }

    public int randX()
    {
        int i = (int) (Math.random()*WIDTH);
        if(i>1200)
        {
            return randX();
        }
        return i;
    }

    public void spawnWave(int num)
    {
        double x = 0;
        boolean b = true;
        while(b)
        {
            x=((int)(Math.random()*HEIGHT));
            if(x+(num*90)<=HEIGHT) b = false;
        }
        System.out.println(x);

        for(int i=0; i<num; i++)
        {
            enemies.add(new Enemy(WIDTH + (i*20), x + i*(80), 50, 70, -1, 0, FIGHTERMAXHP, tieFighter, "tieFighter", (int)(Math.random()+1 * 10)*1000 - (100*i)));
        }
    }

    public void spawnWaveRand(int num)
    {
        for(int i=0; i<num; i++)
        {
            enemies.add(new Enemy(WIDTH, randY(), 50, 80, -1, 0, FIGHTERMAXHP, tieFighter, "tieFighter", (int)(Math.random()+1*10000)));
        }
    }

    public int posNeg1()
    {
        double i = Math.random();
        if(i > .5) return 1;
        else return -1;
    }

    public void attack1(int x, int y)
    {
        // for(int i=0; i<15; i++)
        // {
        //     enemyProjectiles.add(new EnemyProjectile(x, y, 30, 10, -(1.5*Math.cos(.786*(15-i/15))), -(1.5*Math.sin(.786*(15-i/15))), laserGreen, "laser"));
        //     enemyProjectiles.add(new EnemyProjectile(x, y, 30, 10, -1-(15*i), 1 -(1*i), laserGreen, "laser"));
        // }
        for(int i=0; i<11; i++) enemyProjectiles.add(new EnemyProjectile(x-50, y, 10, 10, -5, -5 + i, energyBall, "laser"));
        for(int i=0; i<11; i++) enemyProjectiles.add(new EnemyProjectile(x-50, y+(int)(Math.random()+1*30), 10, 10, -6, -5 + i, energyBall, "laser"));
        for(int i=0; i<11; i++) enemyProjectiles.add(new EnemyProjectile(x-50, y-(int)(Math.random()+1*50), 10, 10, -7, -5 + i, energyBall, "laser"));
    }

    public void laserAttack(int y)
    {
        int currentTime=runningTime;
        enemyProjectiles.add(new EnemyProjectile(0, y+20, WIDTH, 30, 0, 0, null, "start", currentTime+2));
    }
    public void laserAttack()
    {
        int randNum=(int)(Math.random()*2);
        boolean b = (randNum==0);
        int currentTime=runningTime;
        if(b) enemyProjectiles.add(new EnemyProjectile(0, randY(), WIDTH, 20, 0, 0, null, "start", currentTime+2));
        else enemyProjectiles.add(new EnemyProjectile(randX(), 0, 20, HEIGHT, 0, 0, null, "start", currentTime+2));
    }

    public void laserAttack(boolean b)
    {
        int currentTime=runningTime;
        if(b) enemyProjectiles.add(new EnemyProjectile(0, randY(), WIDTH, 20, 0, 0, null, "start", currentTime+2));
        else enemyProjectiles.add(new EnemyProjectile(randX(), 0, 20, HEIGHT, 0, 0, null, "start", currentTime+2));
    }
}
