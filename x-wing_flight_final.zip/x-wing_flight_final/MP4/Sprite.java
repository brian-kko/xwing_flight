import java.awt.*;
import java.util.ArrayList;
import java.awt.image.*;

import javax.swing.ImageIcon;

public class Sprite 
{
    Rectangle rect;
    double xVelocity;
    double yVelocity;
    Image image;
    int duration;

    public Sprite(double x, double y, int width, int height, double xVelocity, double yVelocity)
    {
        this.rect = new Rectangle((int)x,(int)y,width,height);
        this.xVelocity = xVelocity;
        this.yVelocity = yVelocity;
    }

    public Sprite(double x, double y, int width, int height, Image image, int duration)
    {
        this.rect = new Rectangle((int)x,(int)y,width,height);
        this.duration=duration;
        this.image=image;
    }

    public Sprite(double x, double y, int width, int height, double xVelocity, double yVelocity, Image image)
    {
        this.rect = new Rectangle((int)x,(int)y,width,height);
        this.xVelocity = xVelocity;
        this.yVelocity = yVelocity;
        this.image = image;
    }

    public void draw(Graphics2D g2d)
    {
        if(image == null) g2d.fillRect(rect.x, rect.y, rect.width, rect.height);
        else g2d.drawImage(image, rect.x, rect.y, null);
    }

    public boolean collidesWith(Sprite s)
    {
        s = (Sprite) s;
        return s.getRect().intersects(rect);
    }

    public ArrayList<Sprite> collidesWith(ArrayList<Sprite> sprites)
    {
        ArrayList<Sprite> collidesWith = new ArrayList<Sprite>();
        for(Sprite sprite: sprites)
        {
            if(collidesWith(sprite)) collidesWith.add(sprite);
        }
        return collidesWith;
    }

    public static Image resizeImg(String path, int width, int height)
    {
        ImageIcon ii = new ImageIcon(path);
        BufferedImage bi = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = (Graphics2D) bi.createGraphics();
        g2d.addRenderingHints(new RenderingHints(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY));
        boolean b = g2d.drawImage(ii.getImage(), 0, 0, width, height, null);
        System.out.println(b);
        return bi;
    }

    public static Image rotate(Image i, double angle) 
    {
        BufferedImage image = (BufferedImage) i;
        double sin = Math.abs(Math.sin(angle)), cos = Math.abs(Math.cos(angle));
        int w = image.getWidth(), h = image.getHeight();
        int neww = (int)Math.floor(w*cos+h*sin), newh = (int) Math.floor(h * cos + w * sin);
        GraphicsConfiguration gc = getDefaultConfiguration();
        BufferedImage result = gc.createCompatibleImage(neww, newh, Transparency.TRANSLUCENT);
        Graphics2D g = result.createGraphics();
        g.translate((neww - w) / 2, (newh - h) / 2);
        g.rotate(angle, w / 2, h / 2);
        g.drawRenderedImage(image, null);
        g.dispose();
        return result;
    }
    
    private static GraphicsConfiguration getDefaultConfiguration() {
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        GraphicsDevice gd = ge.getDefaultScreenDevice();
        return gd.getDefaultConfiguration();
    }

    public boolean passedX(Sprite other) {return this.x() < other.x();}
    public boolean passedX(double i) {return this.x() < i;}

    public Rectangle getRect() {return rect;}
    public double x() {return rect.x;}
    public double y() {return rect.y;}
    public double xVelocity() {return xVelocity;}
    public double yVelocity() {return yVelocity;}
    public int height() {return rect.height;}
    public int width() {return rect.width;}
    public int duration() {return duration;}
    public void setDuration() {duration--;}
    public Image image() {return image;}
    public void setX(double i) {rect.x =(int) i;}
    public void setY(double i) {rect.y = (int) i;}
    public void setXVelocity(double i) {xVelocity = i;}
    public void setYVelocity(double i) {yVelocity = i;}
    public void setHeight(int i) {rect.height = i;}
    public void setWidth(int i) {rect.width = i;}
    public void setImage(Image i) {image = i;}

}
