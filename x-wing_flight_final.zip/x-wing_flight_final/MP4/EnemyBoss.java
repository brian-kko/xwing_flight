import java.awt.*;

public class EnemyBoss extends Enemy 
{
    public static int targetX;
    public static int targetY;
    public static int startCD;
    private int shield;
    private boolean performingAction;

    //Tie Advanced
    public static boolean action1;
    public static boolean action2;
    public static boolean action3;

    public EnemyBoss(double x, double y, int width, int height, double xVelocity, double yVelocity, int health, Image image, String name, int cooldown)
    {
        super(x,y,width,height,xVelocity,yVelocity,health,image,name,cooldown);  
    }

    public EnemyBoss(double x, double y, int width, int height, double xVelocity, double yVelocity, int health, int shield, Image image, String name, int cooldown, int yDir) 
    {
        super(x, y, width, height, xVelocity, yVelocity, health, image, name, cooldown, yDir);
        this.shield=shield;
    }

    public void draw(Graphics2D g2d)
    {
        if(name.equals("tie"))
        {
            if(image == null) g2d.fillRect(rect.x, rect.y, rect.width, rect.height);
            else g2d.drawImage(image, rect.x, rect.y, null);

            if(shield >= 0)
            {
                g2d.setColor(Color.WHITE);
                g2d.fillRect(325, 75, 600, 30);

                g2d.setColor(Color.BLUE);
                g2d.fillRect(325, 75, 600/20*shield, 30);
            }

            if(shield == 0)
            {
                g2d.setColor(Color.RED);
                g2d.fillRect(325, 75, 600, 30);

                g2d.setColor(Color.GREEN);
                g2d.fillRect(325, 75, 600/40*health, 30);
            }
        }

        if(name.equals("destroyer"))
        {
            if(image == null) g2d.fillRect(rect.x, rect.y, rect.width, rect.height);
            else g2d.drawImage(image, rect.x-450, rect.y-50, null);

            if(yDir==1)
            {    if(shield >= 0)
                {
                    g2d.setColor(Color.WHITE);
                    g2d.fillRect(325, 75, 600, 30);

                    g2d.setColor(Color.BLUE);
                    g2d.fillRect(325, 75, 600/40*shield, 30);
                }

                if(shield == 0)
                {
                    g2d.setColor(Color.RED);
                    g2d.fillRect(325, 75, 600, 30);

                    g2d.setColor(Color.GREEN);
                    g2d.fillRect(325, 75, 600/30*health, 30);
                }
            }
        }

        if(name.equals("death"))
        {
            if(image == null) g2d.fillRect(rect.x, rect.y, rect.width, rect.height);
            else g2d.drawImage(image, rect.x, rect.y, null);
        }
        
    }

    public boolean performingAction() {return performingAction;}
    public void setPerformingAction(boolean i) {performingAction=i;}

    public int shield() {return shield;}
    public void setShield(int i) {shield=i;}
    public void changeTargetCoord(double x, double y) {targetX=(int)x; targetY=(int)y;}
}
