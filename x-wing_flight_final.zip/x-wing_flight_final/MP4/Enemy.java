import java.awt.*;
public class Enemy extends Sprite
{
    private final int BOMBERMAXHP = 10;
    private final int FIGHTERMAXHP = 5;

    int health;
    int cooldown;
    String name;
    int yDir;

    public Enemy(double x, double y, int width, int height, double xVelocity, double yVelocity, int health) {
        super(x, y, width, height, xVelocity, yVelocity);
        this.health = health;
    }

    public Enemy(double x, double y, int width, int height, double xVelocity, double yVelocity, int health, Image image, String name, int cooldown) 
    {
        super(x, y, width, height, xVelocity, yVelocity, image);
        this.health = health;
        this.cooldown = cooldown;
        this.name=name;
    }

    public Enemy(double x, double y, int width, int height, double xVelocity, double yVelocity, int health, Image image, String name, int cooldown, int yDir) 
    {
        super(x, y, width, height, xVelocity, yVelocity, image);
        this.health = health;
        this.cooldown = cooldown;
        this.name=name;
        this.yDir=yDir;
    }

    public void draw(Graphics2D g2d)
    {
        if(image == null) g2d.fillRect(rect.x, rect.y, rect.width, rect.height);
        else g2d.drawImage(image, rect.x -25, rect.y, null);

        if(name.equals("tieFighter"))
        {
            if(health < FIGHTERMAXHP)
            {
                g2d.setColor(Color.RED);
                g2d.fillRect(rect.x, rect.y - 20, rect.width, 12);

                g2d.setColor(Color.GREEN);
                g2d.fillRect(rect.x, rect.y - 20, rect.width / FIGHTERMAXHP * health, 12);
            }
        }
        if(name.equals("tieBomber"))
        {
            if(health < BOMBERMAXHP)
            {
                g2d.setColor(Color.RED);
                g2d.fillRect(rect.x, rect.y - 20, rect.width, 12);

                g2d.setColor(Color.GREEN);
                g2d.fillRect(rect.x, rect.y - 20, rect.width / BOMBERMAXHP * health, 12);
            }
        }
    }

    public int health() {return health;}
    public double yDir() {return yDir;}
    public void setYDir(int i) {yDir = i;}
    
    public int cooldown() {return cooldown;}
    public void setCooldown(int i) {cooldown=i;}

    public void setHealth(int i)
    {
        health = i;
    }
}
