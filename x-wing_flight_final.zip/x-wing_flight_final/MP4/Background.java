import java.awt.*;

public class Background
{
    Image image;
    double x;
    double y;
    int speed;
    
    public Background(Image image, double x, double y)
    {
        this.image=image;
        this.x = x;
        this.y = y;
    }

    public void draw(Graphics2D g2d) {g2d.drawImage(image, (int)x, (int) y, null);}

    public double x() {return x;}
    public double y() {return y;}
    public void setX(double i) {x = i;}
    public void setY(double i) {y = i;}
}
