import javax.swing.*;

public class Frame extends JFrame
{
    Panel panel;
    
    public Frame()
    {
        this.setFocusable(false);
        panel = new Panel(this);
        this.add(panel);
        this.setSize(1280, 720);
        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.pack();
        this.setVisible(true);
    }
}
