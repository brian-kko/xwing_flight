import java.awt.*;
public class Player extends Sprite
{
    int health;
    int shield;
    int torpedoCount;
    Rectangle rect1;

    public Player(double x, double y, int width, int height, double xVelocity, double yVelocity, int health, int shield, Image image) {
        super(x, y, width, height, xVelocity, yVelocity, image);
        this.health = health;
        this.shield = shield;
    }

    public void draw(Graphics2D g2d)
    {
        if(image == null) 
        {
            g2d.setColor(new Color(0,0,0,0));
            g2d.fillRect((int)super.x(),(int) super.y(), super.width(), super.height());
        }
        if(image!=null) g2d.drawImage(image, rect.x, rect.y, null);

        if(shield <= 5 && shield > 0 && health>0)
        {
            g2d.setColor(Color.WHITE);
            g2d.fillRect(rect.x, rect.y - 20, rect.width, 12);

            g2d.setColor(Color.BLUE);
            g2d.fillRect(rect.x, rect.y - 20, rect.width / 5 * shield, 12);
        }

        if(shield <= 0 && health >0)
        {
            g2d.setColor(Color.RED);
            g2d.fillRect(rect.x, rect.y - 20, rect.width, 12);

            g2d.setColor(Color.GREEN);
            g2d.fillRect(rect.x, rect.y - 20, rect.width / 7 * health, 12);
        }
    }

    public int health() {return health;}
    public int shield() {return shield;}
    public int torpedoCount() {return torpedoCount;}

    public void setHealth(int i) {health = i;}
    public void setShield(int i) {shield = i;}
    public void setTorpedo(int i) {torpedoCount = i;}
    public void decreaseHealth(int i) {health = health - i;}
    public void decreaseShield(int i) {shield = shield - i;}
    public void decreaseTorpedo(int i) {torpedoCount = torpedoCount - 1;}
    
}
