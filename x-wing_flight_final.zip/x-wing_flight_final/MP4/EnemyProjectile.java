import java.awt.*;

public class EnemyProjectile extends Sprite
{
    private String name;
    // private int startTime;
    private int endTime;
    private boolean hit;
    
    public EnemyProjectile(double x, double y, int width, int height, double xVelocity, double yVelocity, Image image, String name)
    {
        super(x, y, width, height, xVelocity, yVelocity, image);
        this.name = name;
    }

    public EnemyProjectile(double x, double y, int width, int height, double xVelocity, double yVelocity, Image image, String name, int endTime, boolean hit)
    {
        super(x, y, width, height, xVelocity, yVelocity, image);
        this.name = name;
        // this.startTime=startTime;
        this.endTime=endTime;
        this.hit=false;
    }

    public EnemyProjectile(double x, double y, int width, int height, double xVelocity, double yVelocity, Image image, String name, int endTime)
    {
        super(x, y, width, height, xVelocity, yVelocity, image);
        this.name = name;
        this.endTime=endTime;
    }

    public String name() {return name;}

    public void draw(Graphics2D g2d)
    { 
        if(image == null) 
        {
            if(name.equals("start")) g2d.setColor(new Color(5, 240, 75));
            if(name.equals("end")) g2d.setColor(new Color(5, 240, 67, 250));
            g2d.fillRect(rect.x, rect.y, rect.width, rect.height);
        }
        else g2d.drawImage(image, rect.x, rect.y, null);
    }

    public int endTime() {return endTime;}
    public boolean hit() {return hit;}
    public void setHit(boolean b) {hit =b;}
}
